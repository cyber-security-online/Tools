# Convert Programm 
# Author: Florian André Dalwigk	
import sys
import io

# Erstellt Satzartstrukturen.
def satzart(satzart):
	# Spalteneinschub
	einschub = "				"
	# Variable für den generierten Satzart-Code
	satz_block = ""
	satz_block += (einschub + "<satz>\n")
	for satz in satzart:
		satz_block += (einschub + "	<mm name=\"" + satz[0] + "\">\n")
		satz_block += (einschub + "		<wert>" + satz[1] + "</wert>\n")
		satz_block += (einschub + "	</mm>\n")
	satz_block += (einschub + "</satz>\n")
	return satz_block

# Main-Funktion
def main():
	with io.open("convert.csv") as file:
		lines = file.read()
		lines = lines.split("\n")
	# Definiere eine Liste, die den gesplitteten File-Content enthält.
	content = []
	
	# Iteriere über die Liste und splitte am Semikolon.
	for line in lines:
		content.append(line.split(";"))
	
	# Definiere Variable für resultierenden XML-Content.
	xml_content = ""
		
	# Baue XML-File auf.
	xml_content = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n"
	xml_content += "<DatML-RAW-D xmlns=\"http://www.destatis.de/schema/datml-raw/2.0/de\" version=\"2.0\">\n"
	xml_content += "	<protokoll>\n"
	xml_content += "		<dokumentinstanz>\n"
	xml_content += ("			<datum>" + content[1][1] + "</datum>\n")
	xml_content += ("			<uhrzeit>" + content[1][2] + "</uhrzeit>\n")
	xml_content += ("			<anwendung>\n")
	xml_content += ("				<anwendungsname>" + content[1][3] + "</anwendungsname>\n")
	xml_content += ("				<version>" + content[1][4] + "</version>\n")
	xml_content += ("			</anwendung>\n")
	xml_content += ("		</dokumentinstanz>\n")
	xml_content += ("	</protokoll>\n")
	xml_content += ("	<absender>\n")
	xml_content += ("		<kennung klasse=\"" + content[1][6] + "\">0" + content[1][5] + "</kennung>\n")
	xml_content += ("		<identifikation>\n")
	xml_content += ("			<identitaet>\n")
	xml_content += ("				<organisation>\n")
	xml_content += ("				<name>" + content[1][7] + "</name>\n")
	xml_content += ("				</organisation>\n")
	xml_content += ("			</identitaet>\n")
	xml_content += ("			<adresse>\n")
	xml_content += ("				<strasse>" + content[1][8] +"</strasse>\n")
	xml_content += ("				<hausnummer>" + content[1][9] +"</hausnummer>\n")
	xml_content += ("				<postleitzahl>" + content[1][10] +"</postleitzahl>\n")
	xml_content += ("				<ort>" + content[1][11] +"</ort>\n")
	xml_content += ("			</adresse>\n")
	xml_content += ("		</identifikation>\n")
	xml_content += ("		<kontakt>\n")
	xml_content += ("			<identitaet>\n")
	xml_content += ("				<person>\n")
	xml_content += ("					<nachname>" + content[1][12] + "</nachname>\n")
	xml_content += ("				</person>\n")
	xml_content += ("			</identitaet>\n")
	xml_content += ("			<telefon>" + content[1][13] + "</telefon>\n")
	xml_content += ("		</kontakt>\n")
	xml_content += ("	</absender>\n")
	xml_content += ("	<empfaenger>\n")
	xml_content += ("	<kennung klasse=\"" + content[1][15] + "\">" + content[1][14] + "</kennung>\n")
	xml_content += ("	</empfaenger>\n")
	xml_content += ("	<nachricht>\n")
	xml_content += ("		<erhebung>\n")
	xml_content += ("			<kennung klasse=\"" + content[1][17] + "\">" + "00" + content[1][16] + "</kennung>\n")
	xml_content += ("			<text>" + content[1][18] + "</text>\n")
	xml_content += ("		</erhebung>\n")
	xml_content += ("		<berichtszeitraum>\n")
	xml_content += ("			<jahr>" + content[1][19] + "</jahr>\n")
	xml_content += ("		</berichtszeitraum>\n")
	xml_content += ("		<berichtsempfaenger>\n")
	xml_content += ("			<kennung klasse=\"" + content[1][21] + "\">" + "0" + content[1][20] + "</kennung>\n")
	xml_content += ("		</berichtsempfaenger>\n")
	xml_content += ("		<segment>\n")
	xml_content += ("			<hmm name=\"" + content[1][22] + "\">\n")
	xml_content += ("			<wert>" + content[1][23] + "</wert>\n")
	xml_content += ("			</hmm>\n")
	xml_content += ("			<hmm name=\"" + content[2][22] + "\">\n")
	xml_content += ("				<wert>" + content[2][23] + "</wert>\n")
	xml_content += ("			</hmm>\n")
	xml_content += ("			<hmm name=\"" + content[3][22] + "\">\n")
	xml_content += ("				<wert>" + content[3][23] + "</wert>\n")
	xml_content += ("			</hmm>\n")
	xml_content += ("			<datensegment>\n")		
		
	for i in range(0, len(lines)):
		satz = []
		if "Satzart" in lines[i]:
			for j in range(i, len(lines)-1):
				if i == j or "Satzart" not in lines[j]:
					tmp = []
					length = len(lines[j].split(";"))
					# 'name' eintragen.
					tmp.append(lines[j].split(";")[length-2])
					# 'wert' eintragen.
					tmp.append(lines[j].split(";")[length-1])
					satz.append(tmp)
				elif i != j and "Satzart" in lines[j]:
					break
			xml_content += satzart(satz)
		
	xml_content += ("			</datensegment>\n")
	xml_content += ("		</segment>\n")
	xml_content += ("	</nachricht>\n")
	xml_content += ("</DatML-RAW-D>")
		
		# XML-Dokument als File schreiben.
	output = open("output.xml", "w", encoding="utf8")
	output.write(xml_content)
	output.close()

# Starte Programm
main()